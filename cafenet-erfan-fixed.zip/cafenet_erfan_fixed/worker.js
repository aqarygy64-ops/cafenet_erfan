/**
 * Cloudflare Worker Backend for Cafenet Erfan & Bale Bot Integration
 * Bindings: D1 Database (DB), R2 Bucket (BUCKET)
 * Secrets: ADMIN_PASSWORD_HASH, JWT_SECRET, BALE_BOT_TOKEN, BALE_ADMIN_CHAT_ID
 */

const ALLOWED_EXTENSIONS = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx', 'zip'];
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB
const MAX_FILES_COUNT = 5;
const MAX_TEXT_LENGTH = 4000;

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const method = request.method;

    const corsHeaders = { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" };

    if (method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders });

    try {
      // ۱. ثبت سفارش جدید توسط مشتری
      if (url.pathname === "/api/orders" && method === "POST") {
        return await handleCreateOrder(request, env, corsHeaders);
      }

      // ۲. پیگیری سفارش توسط مشتری با کد رهگیری
      if (url.pathname.startsWith("/api/track/") && method === "GET") {
        const trackingCode = decodeURIComponent(url.pathname.split("/").pop() || "");
        if (!/^ERFAN-[A-F0-9]{16}$/.test(trackingCode)) return jsonResponse({ error: "کد رهگیری نامعتبر است." }, 400, corsHeaders);
        return await handleTrackOrder(trackingCode, env, corsHeaders);
      }

      // ۳. احراز هویت و ورود مدیر
      if (url.pathname === "/api/admin/login" && method === "POST") {
        return await handleAdminLogin(request, env, corsHeaders);
      }

      // بخش مدیریت (نیازمند توکن معتبر)
      if (url.pathname.startsWith("/api/admin/")) {
        const isAuthenticated = await verifyAdminToken(request, env);
        if (!isAuthenticated) {
          return jsonResponse({ error: "دسترسی غیرمجاز. لطفاً وارد شوید." }, 401, corsHeaders);
        }

        // دریافت لیست تمام سفارش‌ها
        if (url.pathname === "/api/admin/orders" && method === "GET") {
          const { results } = await env.DB.prepare(
            "SELECT * FROM orders ORDER BY created_at DESC"
          ).all();
          return jsonResponse({ orders: results }, 200, corsHeaders);
        }

        // تغییر وضعیت سفارش یا ثبت یادداشت مدیریتی
        if (url.pathname.startsWith("/api/admin/orders/") && method === "PATCH") {
          const orderId = url.pathname.split("/").pop();
          if (!/^\d+$/.test(orderId)) return jsonResponse({ error: "شناسه سفارش نامعتبر است." }, 400, corsHeaders);
          const body = await request.json();
          if (!body || typeof body !== "object" || Array.isArray(body)) return jsonResponse({ error: "درخواست نامعتبر است." }, 400, corsHeaders);
          if (body.admin_note !== undefined && (typeof body.admin_note !== "string" || body.admin_note.length > 2000)) return jsonResponse({ error: "یادداشت نامعتبر یا بیش از حد طولانی است." }, 400, corsHeaders);
          
          if (body.status) {
            const validStatuses = ["جدید", "در حال انجام", "تکمیل‌شده", "لغوشده"];
            if (!validStatuses.includes(body.status)) {
              return jsonResponse({ error: "وضعیت نامعتبر است." }, 400, corsHeaders);
            }
            await env.DB.prepare("UPDATE orders SET status = ? WHERE id = ?")
              .bind(body.status, orderId)
              .run();

            // ارسال اعلان تغییر وضعیت به ربات بله
            ctx.waitUntil(sendBaleStatusUpdateNotification(orderId, body.status, env));
          }

          if (body.admin_note !== undefined) {
            await env.DB.prepare("UPDATE orders SET admin_note = ? WHERE id = ?")
              .bind(body.admin_note, orderId)
              .run();
          }

          return jsonResponse({ success: true }, 200, corsHeaders);
        }

        // حذف سفارش و فایل‌های R2 مربوطه
        if (url.pathname.startsWith("/api/admin/orders/") && method === "DELETE") {
          const orderId = url.pathname.split("/").pop();
          if (!/^\d+$/.test(orderId)) return jsonResponse({ error: "شناسه سفارش نامعتبر است." }, 400, corsHeaders);
          const order = await env.DB.prepare("SELECT files FROM orders WHERE id = ?")
            .bind(orderId)
            .first();

          if (order && order.files) {
            const filesList = JSON.parse(order.files);
            for (const f of filesList) {
              await env.BUCKET.delete(f.key);
            }
          }

          await env.DB.prepare("DELETE FROM orders WHERE id = ?")
            .bind(orderId)
            .run();

          return jsonResponse({ success: true }, 200, corsHeaders);
        }

        // دانلود امن فایل از R2
        if (url.pathname.startsWith("/api/admin/files/") && method === "GET") {
          const fileKey = decodeURIComponent(url.pathname.replace("/api/admin/files/", ""));
          if (!fileKey.startsWith("orders/") || fileKey.includes("..")) return jsonResponse({ error: "مسیر فایل نامعتبر است." }, 400, corsHeaders);
          const object = await env.BUCKET.get(fileKey);

          if (!object) {
            return jsonResponse({ error: "فایل یافت نشد." }, 404, corsHeaders);
          }

          const headers = new Headers(corsHeaders);
          object.writeHttpMetadata(headers);
          headers.set("etag", object.httpEtag);

          return new Response(object.body, { headers });
        }
      }

      if (env.ASSETS && method === "GET") return env.ASSETS.fetch(request);
      return jsonResponse({ error: "مسیر مورد نظر یافت نشد." }, 404, corsHeaders);

    } catch (err) {
      return jsonResponse({ error: "خطای داخلی سرور رخ داد." }, 500, corsHeaders);
    }
  }
};

// توابع کمکی
async function handleCreateOrder(request, env, corsHeaders) {
  const formData = await request.formData();

  const customerName = (formData.get("customer_name") || "").toString().trim();
  const customerPhone = (formData.get("customer_phone") || "").toString().trim();
  const category = (formData.get("category") || "").toString().trim();
  const serviceName = (formData.get("service_name") || "").toString().trim();
  const description = (formData.get("description") || "").toString().trim();
  const smartDataStr = (formData.get("smart_data") || "{}").toString();

  if (!customerName || !customerPhone || !category || !serviceName) {
    return jsonResponse({ error: "لطفاً تمام فیلدهای اجباری را تکمیل کنید." }, 400, corsHeaders);
  }

  if (!/^09\d{9}$/.test(customerPhone)) {
    return jsonResponse({ error: "فرمت شماره موبایل نامعتبر است." }, 400, corsHeaders);
  }

  if ([customerName, category, serviceName, description].some(v => v.length > MAX_TEXT_LENGTH)) return jsonResponse({ error: "طول یکی از فیلدها بیش از حد مجاز است." }, 400, corsHeaders);
  let smartData;
  try { smartData = JSON.parse(smartDataStr); } catch { return jsonResponse({ error: "اطلاعات تکمیلی نامعتبر است." }, 400, corsHeaders); }
  if (!smartData || typeof smartData !== "object" || Array.isArray(smartData) || JSON.stringify(smartData).length > 3000) return jsonResponse({ error: "اطلاعات تکمیلی نامعتبر یا بیش از حد طولانی است." }, 400, corsHeaders);

  const uploadedFiles = formData.getAll("files");
  if (uploadedFiles.length > MAX_FILES_COUNT) {
    return jsonResponse({ error: `حداکثر ${MAX_FILES_COUNT} فایل مجاز است.` }, 400, corsHeaders);
  }

  const savedFilesMeta = [];

  for (const file of uploadedFiles) {
    if (file && typeof file === "object" && file.size > 0) {
      if (file.size > MAX_FILE_SIZE) {
        return jsonResponse({ error: `حجم فایل ${file.name} بیشتر از ۱۰ مگابایت است.` }, 400, corsHeaders);
      }

      const ext = file.name.split(".").pop().toLowerCase();
      if (!ALLOWED_EXTENSIONS.includes(ext)) {
        return jsonResponse({ error: `پسوند فایل ${file.name} مجاز نیست.` }, 400, corsHeaders);
      }

      const uniqueKey = `orders/${Date.now()}-${crypto.randomUUID()}.${ext}`;
      await env.BUCKET.put(uniqueKey, file.stream(), {
        httpMetadata: { contentType: file.type || "application/octet-stream" }
      });

      savedFilesMeta.push({
        key: uniqueKey,
        originalName: file.name,
        size: file.size
      });
    }
  }

  const trackingBytes = crypto.getRandomValues(new Uint8Array(8));
  const trackingCode = "ERFAN-" + Array.from(trackingBytes, b => b.toString(16).padStart(2, "0")).join("").toUpperCase();
  const createdAt = new Date().toISOString();

  const result = await env.DB.prepare(
    `INSERT INTO orders (tracking_code, customer_name, customer_phone, category, service_name, description, smart_data, files, status, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'جدید', ?)`
  )
    .bind(
      trackingCode,
      customerName,
      customerPhone,
      category,
      serviceName,
      description,
      smartDataStr,
      JSON.stringify(savedFilesMeta),
      createdAt
    )
    .run();

  const orderObj = {
    id: result.meta.last_row_id,
    tracking_code: trackingCode,
    customer_name: customerName,
    customer_phone: customerPhone,
    category,
    service_name: serviceName,
    description,
    files: savedFilesMeta
  };

  // ارسال اعلان به ربات بله
  if (env.BALE_BOT_TOKEN && env.BALE_ADMIN_CHAT_ID) {
    try {
      await sendBaleNewOrderNotification(orderObj, env);
    } catch (e) {
      // ثبت خطا بدون توقف روند سفارش
    }
  }

  return jsonResponse({
    success: true,
    order_id: result.meta.last_row_id,
    tracking_code: trackingCode
  }, 201, corsHeaders);
}

async function handleTrackOrder(trackingCode, env, corsHeaders) {
  if (!trackingCode) {
    return jsonResponse({ error: "کد رهگیری الزامی است." }, 400, corsHeaders);
  }

  const order = await env.DB.prepare(
    "SELECT tracking_code, category, service_name, status, admin_note, created_at FROM orders WHERE tracking_code = ?"
  )
    .bind(trackingCode)
    .first();

  if (!order) {
    return jsonResponse({ error: "سفارشی با این کد رهگیری یافت نشد." }, 404, corsHeaders);
  }

  return jsonResponse({ success: true, order }, 200, corsHeaders);
}

async function handleAdminLogin(request, env, corsHeaders) {
  const { password } = await request.json();
  if (!password) {
    return jsonResponse({ error: "رمز عبور الزامی است." }, 400, corsHeaders);
  }

  if (!env.ADMIN_PASSWORD_HASH || !(await verifyPassword(password, env.ADMIN_PASSWORD_HASH))) {
    return jsonResponse({ error: "رمز عبور مدیریت اشتباه است." }, 401, corsHeaders);
  }

  const payload = {
    role: "admin",
    exp: Date.now() + 24 * 60 * 60 * 1000
  };
  const token = await signToken(payload, env.JWT_SECRET);

  return jsonResponse({ success: true, token }, 200, corsHeaders);
}

// اعلان بله؛ پیش از فعال‌سازی، نشانی API را با مستندات رسمی بله تطبیق دهید.
async function sendBaleMessage(text, env) {
  if (!env.BALE_BOT_TOKEN || !env.BALE_ADMIN_CHAT_ID) return;
  const endpoint = `https://tapi.bale.ai/bot${env.BALE_BOT_TOKEN}/sendMessage`;
  const response = await fetch(endpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chat_id: env.BALE_ADMIN_CHAT_ID, text }) });
  if (!response.ok) throw new Error(`Bale API HTTP ${response.status}`);
  const result = await response.json().catch(() => ({}));
  if (result.ok === false) throw new Error("Bale API rejected the message");
}
async function sendBaleNewOrderNotification(order, env) {
  const message = `🔔 سفارش جدید کافینت عرفان\n\nکد رهگیری: ${order.tracking_code}\nنام مشتری: ${order.customer_name}\nشماره تماس: ${order.customer_phone}\nدسته‌بندی: ${order.category}\nخدمت: ${order.service_name}\nتوضیحات: ${order.description || "ندارد"}\nتعداد فایل پیوست: ${order.files.length}`;
  await sendBaleMessage(message, env);
}
async function sendBaleStatusUpdateNotification(orderId, newStatus, env) {
  if (!env.BALE_BOT_TOKEN || !env.BALE_ADMIN_CHAT_ID) return;
  const order = await env.DB.prepare("SELECT tracking_code, customer_name, service_name FROM orders WHERE id = ?").bind(orderId).first();
  if (!order) return;
  await sendBaleMessage(`🔄 تغییر وضعیت سفارش\n\nکد رهگیری: ${order.tracking_code}\nمشتری: ${order.customer_name}\nخدمت: ${order.service_name}\nوضعیت جدید: ${newStatus}`, env);
}

async function verifyAdminToken(request, env) {
  const authHeader = request.headers.get("Authorization") || "";
  if (!authHeader.startsWith("Bearer ")) return false;

  const token = authHeader.slice(7);
  try {
    const [payloadB64, signatureB64] = token.split(".");
    if (!payloadB64 || !signatureB64) return false;

    const expectedSig = await hmacSha256(payloadB64, env.JWT_SECRET);
    if (signatureB64 !== expectedSig) return false;

    const payload = JSON.parse(atob(payloadB64));
    if (payload.role !== "admin" || Date.now() > payload.exp) return false;

    return true;
  } catch {
    return false;
  }
}

async function signToken(payload, secret) {
  const payloadB64 = btoa(JSON.stringify(payload));
  const signatureB64 = await hmacSha256(payloadB64, secret);
  return `${payloadB64}.${signatureB64}`;
}

async function verifyPassword(password, stored) {
  // Format: pbkdf2$iterations$saltHex$derivedKeyHex
  const parts = String(stored).split("$");
  if (parts.length !== 4 || parts[0] !== "pbkdf2") return false;
  const iterations = Number(parts[1]);
  if (!Number.isInteger(iterations) || iterations < 100000 || iterations > 600000) return false;
  try {
    const fromHex = h => {
      if (!/^(?:[0-9a-f]{2})+$/i.test(h)) throw new Error("bad hex");
      return Uint8Array.from(h.match(/.{2}/g), x => parseInt(x, 16));
    };
    const salt = fromHex(parts[2]), expected = fromHex(parts[3]);
    const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
    const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations, hash: "SHA-256" }, key, expected.length * 8);
    const actual = new Uint8Array(bits);
    if (actual.length !== expected.length) return false;
    let diff = 0; for (let i = 0; i < actual.length; i++) diff |= actual[i] ^ expected[i];
    return diff === 0;
  } catch { return false; }
}

async function hmacSha256(data, secret) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(data));
  return btoa(String.fromCharCode(...new Uint8Array(sig)));
}

function jsonResponse(data, status, corsHeaders) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      ...corsHeaders
    }
  });
}
