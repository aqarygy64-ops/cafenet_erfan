import getpass, hashlib, secrets

password = getpass.getpass("رمز مدیریت جدید: ")
if len(password) < 12:
    raise SystemExit("رمز باید حداقل ۱۲ نویسه باشد.")
iterations = 210_000
salt = secrets.token_bytes(16)
derived = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations, dklen=32)
print("\nاین مقدار را به‌عنوان Secret با نام ADMIN_PASSWORD_HASH در Cloudflare ثبت کنید:")
print(f"pbkdf2${iterations}${salt.hex()}${derived.hex()}")
