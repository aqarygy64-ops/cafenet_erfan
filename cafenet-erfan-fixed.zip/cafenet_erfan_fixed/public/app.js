// آدرس ورکر کلادفلر خود را پس از دیپلوی در این متغیر قرار دهید
const API_BASE_URL = ""; // API روی همان دامنه سایت

const SERVICES_DATA = [
    { icon: "🏛️", category: "خدمات دولتی و اداری", title: "ثبت‌نام و استعلامات دولتی", desc: "سامانه‌های دولتی، شناسنامه، کارت ملی و پیگیری مجوزها" },
    { icon: "🚗", category: "خدمات خودرو", title: "ثبت‌نام ایران‌خودرو و سایپا", desc: "طرح مادران، جوانی جمعیت، عادی، وارداتی و لاستیک دولتی" },
    { icon: "⛽", category: "خدمات خودرو", title: "کارت سوخت المثنی و پیگیری", desc: "ثبت‌نام کارت سوخت، تغییر مالکیت و پیگیری کارت هوشمند" },
    { icon: "💰", category: "خدمات یارانه و معیشت", title: "یارانه و کالابرگ الکترونیک", desc: "اعتراض به دهک‌بندی یارانه، کالابرگ و خوداظهاری خانوار" },
    { icon: "⚖️", category: "خدمات قضایی", title: "ثبت‌نام و احراز هویت ثنا", desc: "دریافت ابلاغیه قضایی، گواهی سوءپیشینه و پیگیری پرونده" },
    { icon: "🎓", category: "خدمات آموزشی", title: "کنکور و انتخاب رشته دانشگاه", desc: "ثبت‌نام کنکور سراسری، آزمون استخدامی و انتخاب رشته" },
    { icon: "🏦", category: "خدمات بانکی و مالی", title: "امور مالیاتی و بیمه تامین اجتماعی", desc: "اظهارنامه مالیاتی، سوابق بیمه و تسهیلات بانکی" },
    { icon: "📝", category: "تایپ و تبدیل فایل", title: "تایپ و صفحه‌آرایی Word", desc: "تایپ فوری فارسی و انگلیسی، مقاله، جزوه، رزومه و نامه اداری" },
    { icon: "🔄", category: "تایپ و تبدیل فایل", title: "تبدیل فایل PDF و Word", desc: "تبدیل عکس به PDF، پی‌دی‌اف به ورد، ادغام و فشرده‌سازی" },
    { icon: "🖨️", category: "چاپ و اسکن", title: "پرینت، کپی و اسکن مدارک", desc: "آماده‌سازی فایل جهت چاپ، اسکن رنگی باکیفیت و تکثیر" },
    { icon: "🎨", category: "طراحی گرافیکی", title: "طراحی لوگو، بنر و کارت ویزیت", desc: "طراحی گرافیکی لوگو تجاری، پوستر، تراکت و کارت ویزیت" },
    { icon: "💻", category: "طراحی سایت و اپلیکیشن", title: "طراحی سایت و اپلیکیشن اندروید", desc: "سایت شخصی، شرکتی، فروشگاهی و فرم‌های سفارش اختصاصی" },
    { icon: "⭐", category: "اشتراک‌های دیجیتال و هوش مصنوعی", title: "اشتراک ChatGPT و Gemini", desc: "خرید اکانت قانونی هوش مصنوعی، تلگرام پرمیوم و اسپاتیفای" },
    { icon: "🌐", category: "خدمات اینترنت و کانفیگ", title: "کانفیگ اختصاصی VPN و V2Ray", desc: "تنظیمات اتصال پرسرعت V2RayNG، Hiddify و V2Box" }
];

document.addEventListener("DOMContentLoaded", () => {
    initServicesGrid();
    initSearch();
    initOrderForm();
    initTracking();
});

function initServicesGrid() {
    const grid = document.getElementById("servicesGrid");
    if (!grid) return;
    grid.innerHTML = "";

    SERVICES_DATA.forEach(srv => {
        const div = document.createElement("div");
        div.className = "service-item";
        div.innerHTML = `
            <div class="service-icon">${srv.icon}</div>
            <div class="service-info">
                <h4>${srv.title}</h4>
                <p>${srv.desc}</p>
            </div>
        `;
        div.addEventListener("click", () => {
            document.getElementById("serviceCategory").value = srv.category;
            document.getElementById("serviceExactName").value = srv.title;
            updateSmartFields(srv.category);
            document.getElementById("order").scrollIntoView({ behavior: "smooth" });
        });
        grid.appendChild(div);
    });
}

function initSearch() {
    const input = document.getElementById("serviceSearchInput");
    const btn = document.getElementById("searchBtn");
    if (!input || !btn) return;

    const performSearch = () => {
        const query = input.value.trim().toLowerCase();
        if (!query) return;

        const matched = SERVICES_DATA.find(s => s.title.toLowerCase().includes(query) || s.desc.toLowerCase().includes(query) || s.category.toLowerCase().includes(query));
        if (matched) {
            document.getElementById("serviceCategory").value = matched.category;
            document.getElementById("serviceExactName").value = matched.title;
            updateSmartFields(matched.category);
            document.getElementById("order").scrollIntoView({ behavior: "smooth" });
        } else {
            document.getElementById("serviceCategory").value = "خدمات تکمیلی (سایر)";
            document.getElementById("serviceExactName").value = query;
            updateSmartFields("خدمات تکمیلی (سایر)");
            document.getElementById("order").scrollIntoView({ behavior: "smooth" });
        }
    };

    btn.addEventListener("click", performSearch);
    input.addEventListener("keypress", (e) => { if (e.key === "Enter") performSearch(); });
}

function initOrderForm() {
    const categorySelect = document.getElementById("serviceCategory");
    const fileInput = document.getElementById("orderFiles");
    const fileList = document.getElementById("selectedFilesList");
    const form = document.getElementById("orderForm");

    if (!categorySelect || !form) return;

    categorySelect.addEventListener("change", (e) => {
        updateSmartFields(e.target.value);
    });

    fileInput.addEventListener("change", () => {
        fileList.innerHTML = "";
        if (fileInput.files.length > 5) {
            alert("حداکثر ۵ فایل می‌توانید انتخاب کنید.");
            fileInput.value = "";
            return;
        }
        Array.from(fileInput.files).forEach(file => {
            const sizeMB = (file.size / (1024 * 1024)).toFixed(2);
            const li = document.createElement("li");
            li.textContent = `📎 ${file.name} (${sizeMB} مگابایت)`;
            fileList.appendChild(li);
        });
    });

    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const alertBox = document.getElementById("formAlert");
        const submitBtn = document.getElementById("submitBtn");
        const btnText = document.getElementById("btnText");

        const name = document.getElementById("customerName").value.trim();
        const phone = document.getElementById("customerPhone").value.trim();
        const category = categorySelect.value;
        const exactName = document.getElementById("serviceExactName").value.trim();
        const description = document.getElementById("orderDescription").value.trim();
        
        let smartData = {};
        const smartInput1 = document.getElementById("smartInput1");
        if (smartInput1) smartData[smartInput1.dataset.label] = smartInput1.value.trim();

        if (!/^09\d{9}$/.test(phone)) {
            showAlert(alertBox, "شماره موبایل باید ۱۱ رقم باشد و با 09 شروع شود.", "error");
            return;
        }

        const formData = new FormData();
        formData.append("customer_name", name);
        formData.append("customer_phone", phone);
        formData.append("category", category);
        formData.append("service_name", exactName);
        formData.append("description", description);
        formData.append("smart_data", JSON.stringify(smartData));

        const files = fileInput.files;
        for (let i = 0; i < files.length; i++) {
            formData.append("files", files[i]);
        }

        submitBtn.disabled = true;
        btnText.textContent = "در حال ارسال و ذخیره در سرور...";
        alertBox.classList.add("hidden");

        try {
            const res = await fetch(`${API_BASE_URL}/api/orders`, {
                method: "POST",
                body: formData
            });
            const result = await res.json();

            if (res.ok && result.success) {
                showSuccessModal(result.tracking_code);
                form.reset();
                fileList.innerHTML = "";
                document.getElementById("dynamicSmartFields").innerHTML = "";
            } else {
                showAlert(alertBox, result.error || "خطا در ثبت سفارش.", "error");
            }
        } catch (err) {
            showAlert(alertBox, "خطا در ارتباط با سرور کلادفلر.", "error");
        } finally {
            submitBtn.disabled = false;
            btnText.textContent = "ثبت نهایی سفارش";
        }
    });

    document.getElementById("closeSuccessModal").addEventListener("click", () => {
        document.getElementById("successModal").classList.add("hidden");
    });
}

function initTracking() {
    const btn = document.getElementById("trackBtn");
    const input = document.getElementById("trackCodeInput");
    const resultBox = document.getElementById("trackResultBox");

    if (!btn || !input || !resultBox) return;

    btn.addEventListener("click", async () => {
        const code = input.value.trim().toUpperCase();
        if (!code) {
            alert("لطفاً کد رهگیری را وارد کنید.");
            return;
        }

        resultBox.innerHTML = "<p>در حال استعلام وضعیت سفارش...</p>";
        resultBox.classList.remove("hidden");

        try {
            const res = await fetch(`${API_BASE_URL}/api/track/${encodeURIComponent(code)}`);
            const data = await res.json();

            if (res.ok && data.success) {
                const o = data.order;
                const dateStr = new Date(o.created_at).toLocaleDateString("fa-IR");
                resultBox.innerHTML = `
                    <div class="detail-row"><strong>کد رهگیری:</strong> <span style="color:var(--accent);">${escapeHTML(o.tracking_code)}</span></div>
                    
                    <div class="detail-row"><strong>خدمت درخواستی:</strong> ${escapeHTML(o.service_name)} (${escapeHTML(o.category)})</div>
                    <div class="detail-row"><strong>تاریخ ثبت:</strong> ${dateStr}</div>
                    <div class="detail-row"><strong>وضعیت فعلی:</strong> <span class="status-badge status-${escapeHTML(o.status.replace(/\s+/g, "-"))}">${escapeHTML(o.status)}</span></div>
                    ${o.admin_note ? `<div class="detail-row" style="margin-top:10px;background:rgba(56,189,248,0.1);padding:10px;border-radius:8px;"><strong>توضیحات مدیر:</strong> ${escapeHTML(o.admin_note)}</div>` : ""}
                `;
            } else {
                resultBox.innerHTML = `<p style="color:var(--danger);">${data.error || "سفارشی با این کد رهگیری پیدا نشد."}</p>`;
            }
        } catch (e) {
            resultBox.innerHTML = `<p style="color:var(--danger);">خطا در ارتباط با سرور.</p>`;
        }
    });
}

function updateSmartFields(category) {
    const container = document.getElementById("dynamicSmartFields");
    container.innerHTML = "";

    if (category.includes("دولتی") || category.includes("قضایی") || category.includes("خودرو") || category.includes("یارانه")) {
        container.innerHTML = `
            <div class="form-group" style="margin-bottom:0;">
                <label for="smartInput1">کد ملی <span class="req">*</span></label>
                <input type="text" id="smartInput1" data-label="کد ملی" required placeholder="کد ملی ۱۰ رقمی" maxlength="10">
            </div>
        `;
    } else if (category.includes("اشتراک") || category.includes("هوش مصنوعی")) {
        container.innerHTML = `
            <div class="form-group" style="margin-bottom:0;">
                <label for="smartInput1">آدرس ایمیل (Gmail) <span class="req">*</span></label>
                <input type="email" id="smartInput1" data-label="Gmail" required placeholder="example@gmail.com">
            </div>
        `;
    }
}

function showAlert(element, message, type) {
    element.textContent = message;
    element.className = `alert alert-${type}`;
    element.classList.remove("hidden");
}

function showSuccessModal(code) {
    document.getElementById("trackingCodeBox").textContent = code;
    document.getElementById("successModal").classList.remove("hidden");
}

function escapeHTML(value) {
 return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"}[c]));
}
