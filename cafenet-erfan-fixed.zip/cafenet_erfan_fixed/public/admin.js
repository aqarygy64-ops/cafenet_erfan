const API_BASE_URL = ""; // API روی همان دامنه سایت
let allOrders = [];

document.addEventListener("DOMContentLoaded", () => {
    if (localStorage.getItem("erfan_admin_token")) {
        showDashboard();
    }

    const loginForm = document.getElementById("adminLoginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            const password = document.getElementById("adminPassword").value;
            const alertBox = document.getElementById("loginAlert");
            const loginBtn = document.getElementById("loginBtn");

            loginBtn.disabled = true;
            loginBtn.textContent = "در حال احراز هویت...";

            try {
                const res = await fetch(`${API_BASE_URL}/api/admin/login`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ password })
                });
                const data = await res.json();

                if (res.ok && data.token) {
                    localStorage.setItem("erfan_admin_token", data.token);
                    showDashboard();
                } else {
                    showAlert(alertBox, data.error || "رمز عبور مدیریت اشتباه است.", "error");
                }
            } catch (err) {
                showAlert(alertBox, "خطا در ارتباط با سرور کلادفلر.", "error");
            } finally {
                loginBtn.disabled = false;
                loginBtn.textContent = "ورود به پنل";
            }
        });
    }

    document.getElementById("logoutBtn").addEventListener("click", () => {
        localStorage.removeItem("erfan_admin_token");
        location.reload();
    });

    document.getElementById("searchInput").addEventListener("input", renderOrdersTable);
    document.getElementById("statusFilter").addEventListener("change", renderOrdersTable);
    document.getElementById("refreshBtn").addEventListener("click", fetchOrders);
    document.getElementById("closeModal").addEventListener("click", () => {
        document.getElementById("orderModal").classList.add("hidden");
    });
});

function showDashboard() {
    document.getElementById("loginSection").classList.add("hidden");
    document.getElementById("dashboardSection").classList.remove("hidden");
    fetchOrders();
    setInterval(fetchOrders, 30000);
}

async function fetchOrders() {
    const token = localStorage.getItem("erfan_admin_token");
    const tbody = document.getElementById("ordersTableBody");
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;">در حال دریافت سفارش‌ها از دیتابیس D1...</td></tr>`;

    try {
        const res = await fetch(`${API_BASE_URL}/api/admin/orders`, {
            headers: { "Authorization": `Bearer ${token}` }
        });

        if (res.status === 401) {
            localStorage.removeItem("erfan_admin_token");
            location.reload();
            return;
        }

        const data = await res.json();
        allOrders = data.orders || [];
        updateStats();
        renderOrdersTable();
    } catch (err) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;color:#f87171;">خطا در دریافت لیست سفارش‌ها از سرور</td></tr>`;
    }
}

function updateStats() {
    document.getElementById("statTotal").textContent = allOrders.length;
    document.getElementById("statNew").textContent = allOrders.filter(o => o.status === "جدید").length;
    document.getElementById("statProgress").textContent = allOrders.filter(o => o.status === "در حال انجام").length;
    document.getElementById("statDone").textContent = allOrders.filter(o => o.status === "تکمیل‌شده").length;
}

function renderOrdersTable() {
    const tbody = document.getElementById("ordersTableBody");
    const search = document.getElementById("searchInput").value.toLowerCase().trim();
    const statusFilter = document.getElementById("statusFilter").value;

    const filtered = allOrders.filter(o => {
        const matchesStatus = statusFilter === "all" || o.status === statusFilter;
        const matchesSearch =
            o.customer_name.toLowerCase().includes(search) ||
            o.customer_phone.includes(search) ||
            o.tracking_code.toLowerCase().includes(search) ||
            o.service_name.toLowerCase().includes(search);
        return matchesStatus && matchesSearch;
    });

    if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;">هیچ سفارشی یافت نشد.</td></tr>`;
        return;
    }

    tbody.innerHTML = filtered.map(order => {
        const statusClass = "status-" + order.status.replace(/\s+/g, "-");
        const dateStr = new Date(order.created_at).toLocaleDateString("fa-IR");
        return `
            <tr>
                <td><strong style="color:var(--accent);">${escapeHTML(order.tracking_code)}</strong></td>
                <td>${escapeHTML(order.customer_name)}</td>
                <td dir="ltr">${escapeHTML(order.customer_phone)}</td>
                <td>
                    <div><strong>${escapeHTML(order.service_name)}</strong></div>
                    <small style="color:#94a3b8">${escapeHTML(order.category)}</small>
                </td>
                <td>${dateStr}</td>
                <td><span class="status-badge ${escapeHTML(statusClass)}">${escapeHTML(order.status)}</span></td>
                <td>
                    <button class="btn btn-primary btn-sm" onclick="viewOrderDetails(${order.id})">بررسی / فایل</button>
                    <button class="btn btn-danger btn-sm" onclick="deleteOrder(${order.id})">حذف</button>
                </td>
            </tr>
        `;
    }).join("");
}

window.viewOrderDetails = function(orderId) {
    const order = allOrders.find(o => o.id === orderId);
    if (!order) return;

    document.getElementById("modalOrderId").textContent = `(${order.tracking_code})`;
    const files = order.files ? JSON.parse(order.files) : [];
    const smartData = order.smart_data ? JSON.parse(order.smart_data) : {};

    let smartHtml = "";
    for (const [key, val] of Object.entries(smartData)) {
        if (val) smartHtml += `<div class="detail-row"><strong>${escapeHTML(key)}:</strong> ${escapeHTML(val)}</div>`;
    }

    let filesHtml = "<p style='color:#94a3b8;font-size:0.85rem;'>فایلی پیوست نشده است.</p>";
    if (files.length > 0) {
        filesHtml = files.map(f => `
            <div class="file-download-item">
                <span>📄 ${escapeHTML(f.originalName)}</span>
                <button class="btn btn-primary btn-sm" onclick="downloadSecureFile('${encodeURIComponent(f.key)}', '${escapeHTML(f.originalName)}')">دانلود فایل از R2</button>
            </div>
        `).join("");
    }

    document.getElementById("modalBody").innerHTML = `
        <div class="detail-row"><strong>کد رهگیری:</strong> <span style="color:var(--accent);font-weight:bold;">${escapeHTML(order.tracking_code)}</span></div>
        <div class="detail-row"><strong>نام مشتری:</strong> ${escapeHTML(order.customer_name)}</div>
        <div class="detail-row"><strong>شماره موبایل:</strong> <a href="tel:${order.customer_phone}" style="color:#38bdf8;">${order.customer_phone}</a></div>
        <div class="detail-row"><strong>دسته‌بندی:</strong> ${escapeHTML(order.category)}</div>
        <div class="detail-row"><strong>نام خدمت:</strong> ${escapeHTML(order.service_name)}</div>
        ${smartHtml}
        <div class="detail-row"><strong>توضیحات مشتری:</strong><br><p style="background:#091729;padding:12px;border-radius:8px;margin-top:6px;">${escapeHTML(order.description || "بدون توضیحات")}</p></div>
        <div class="detail-row">
            <strong>تغییر وضعیت سفارش:</strong>
            <select id="modalStatusSelect" style="margin-top:8px;" onchange="updateOrderField(${order.id}, 'status', this.value)">
                <option value="جدید" ${order.status === "جدید" ? "selected" : ""}>جدید</option>
                <option value="در حال انجام" ${order.status === "در حال انجام" ? "selected" : ""}>در حال انجام</option>
                <option value="تکمیل‌شده" ${order.status === "تکمیل‌شده" ? "selected" : ""}>تکمیل‌شده</option>
                <option value="لغوشده" ${order.status === "لغوشده" ? "selected" : ""}>لغوشده</option>
            </select>
        </div>
        <div class="detail-row" style="margin-top:12px;">
            <label for="adminNoteInput"><strong>یادداشت خصوصی مدیر (قابل نمایش در پیگیری مشتری):</strong></label>
            <textarea id="adminNoteInput" rows="3" style="margin-top:6px;" onchange="updateOrderField(${order.id}, 'admin_note', this.value)" placeholder="یادداشت یا توضیحات برای مشتری...">${escapeHTML(order.admin_note || "")}</textarea>
        </div>
        <div class="detail-row" style="margin-top:15px;">
            <strong>مدارک و فایل‌های پیوست شده در R2:</strong>
            ${filesHtml}
        </div>
    `;

    document.getElementById("orderModal").classList.remove("hidden");
};

window.updateOrderField = async function(orderId, field, value) {
    const token = localStorage.getItem("erfan_admin_token");
    const body = {};
    body[field] = value;

    try {
        const res = await fetch(`${API_BASE_URL}/api/admin/orders/${orderId}`, {
            method: "PATCH",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`
            },
            body: JSON.stringify(body)
        });
        if (res.ok) {
            fetchOrders();
        } else {
            alert("خطا در بروزرسانی سفارش.");
        }
    } catch (e) {
        alert("خطا در ارتباط با سرور.");
    }
};

window.deleteOrder = async function(orderId) {
    if (!confirm(`آیا از حذف کامل سفارش #${orderId} و فایل‌های مرتبط با آن اطمینان دارید؟`)) return;
    const token = localStorage.getItem("erfan_admin_token");

    try {
        const res = await fetch(`${API_BASE_URL}/api/admin/orders/${orderId}`, {
            method: "DELETE",
            headers: { "Authorization": `Bearer ${token}` }
        });
        if (res.ok) {
            fetchOrders();
        } else {
            alert("خطا در حذف سفارش.");
        }
    } catch (e) {
        alert("خطا در ارتباط با سرور.");
    }
};

window.downloadSecureFile = async function(fileKey, originalName) {
    const token = localStorage.getItem("erfan_admin_token");
    try {
        const res = await fetch(`${API_BASE_URL}/api/admin/files/${fileKey}`, {
            headers: { "Authorization": `Bearer ${token}` }
        });
        if (!res.ok) {
            alert("خطا در دریافت فایل از R2.");
            return;
        }
        const blob = await res.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = originalName;
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
    } catch (e) {
        alert("خطا در دانلود فایل.");
    }
};

function showAlert(element, message, type) {
    element.textContent = message;
    element.className = `alert alert-${type}`;
    element.classList.remove("hidden");
}

function escapeHTML(str) {
    if (!str) return "";
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
