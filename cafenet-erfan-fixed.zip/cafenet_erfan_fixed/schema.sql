-- پایگاه داده D1 برای کافینت عرفان
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tracking_code TEXT NOT NULL UNIQUE,
    customer_name TEXT NOT NULL,
    customer_phone TEXT NOT NULL,
    category TEXT NOT NULL,
    service_name TEXT NOT NULL,
    description TEXT,
    smart_data TEXT DEFAULT '{}',
    files TEXT DEFAULT '[]',
    status TEXT DEFAULT 'جدید',
    admin_note TEXT DEFAULT '',
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_phone ON orders(customer_phone);
CREATE INDEX IF NOT EXISTS idx_orders_tracking ON orders(tracking_code);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at DESC);
